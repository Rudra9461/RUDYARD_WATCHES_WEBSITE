<?php
include('include/header.php');
?>


<div class="container mt-3"><hr>
	<div class="page_heading p-3 mt-3">HELP & CONTACT</div><hr>
	<div class="row border bg-light p-5">
    <div class="col-sm-4 p-3 bg-info text-dark"> <a href="#"><i class="icon fa fa-commenting icons" aria-hidden="true"></i> </a> </br> CHAT WITH US </div>

    <div class="col-sm-4 p-3 bg-danger text-dark"> <a href="#"><i class="icon fa fa-phone" aria-hidden="true"></i></a></br> CALL US NOW : 9352100428 </div>

    <div class="col-sm-4 p-3 bg-info text-dark"><a href="#"><i class=" icon fa fa-envelope icons" aria-hidden="true"></i></a> </br> Write to Us : pratapsinghr782@gmail.com</div>
	</div>	
	
	<p><strong>The toll free number is only applicable for domestic orders within India. For International customers or deliveries, please reach us out through WhatsApp, Live Chat or email.
	</strong></p>		
</div></div></div>


<?php 
include('include/footer.php');
?>							